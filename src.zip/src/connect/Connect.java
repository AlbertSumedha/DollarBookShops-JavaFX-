package connect;

import java.sql.*;

public class Connect {
    
    private final String USERNAME = "root";
    private final String PASSWORD = "";
    private final String DATABASE = "dbshop";
    private final String HOST = "localhost";
    private final int PORT = 3306; 
    private final String CONNECTION = String.format("jdbc:mysql://%s:%d/%s", HOST, PORT, DATABASE);
    
    public ResultSet rs;
    public ResultSetMetaData rsm;
    
    public static Connection con;
    public Statement st;
    private static Connect connect;
    
    public static Connect getInstance() {
        if (connect == null) {
            connect = new Connect();
        }
        return connect;
    }
    
    private Connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(CONNECTION, USERNAME, PASSWORD);
            st = con.createStatement();
        } catch (SQLException e) {
            System.err.println("Connection failed: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.err.println("JDBC Driver not found: " + e.getMessage());
        }
    }
    
    public void close() {
        try {
            if (rs != null) rs.close();
            if (st != null) st.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            System.err.println("Error closing resources: " + e.getMessage());
        }
    }
    
    public static Connection getConnection() {
        return con;
    }
}