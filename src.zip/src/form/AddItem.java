package form;

import connect.Connect;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import jfxtras.labs.scene.control.window.Window;
import models.Login;

import java.sql.ResultSet;
import java.sql.SQLException;


public class AddItem {

    private Stage primaryStage;
    private String productId, productName, productGenre;
    private int productPrice, productStock;
    private Window window;
    private VBox contentBox;
    private Label nameLabel,genreLabel,priceLabel;
    private Spinner<Integer>quantitySpinner;
    private SpinnerValueFactory<Integer>valueFactory;
    private Button addButton;
    private StackPane root;
    private Scene scene;
    private Stage addItemStage;

    public AddItem(Stage primaryStage, String productId, String productName, String productGenre, int productPrice, int productStock) {
        this.primaryStage = primaryStage;
        this.productId = productId;
        this.productName = productName;
        this.productGenre = productGenre;
        this.productPrice = productPrice;
        this.productStock = productStock;
    }

    public void show() {
        window = new Window("Add to Cart");
        window.setPrefSize(400, 300);

        contentBox = new VBox(10);
        contentBox.setPadding(new Insets(10));

        nameLabel = new Label("Name: " + productName);
        genreLabel = new Label("Genre: " + productGenre);
        priceLabel = new Label("Price: " + productPrice);

        quantitySpinner = new Spinner<>();
        valueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(0, productStock, 1);
        quantitySpinner.setValueFactory(valueFactory);

        int currentQuantity = getCartQuantity(productId);
        if (currentQuantity > 0) {
            valueFactory.setValue(currentQuantity);
        }
        addButton = new Button("Add");
        addButton.setOnAction(e -> handleAddToCart(quantitySpinner.getValue()));
        contentBox.getChildren().addAll(nameLabel, genreLabel, priceLabel, quantitySpinner, addButton);

        window.getContentPane().getChildren().add(contentBox);
        root = new StackPane();
        root.getChildren().add(window);
        scene = new Scene(root, 400, 300);
        addItemStage = new Stage();
        addItemStage.setScene(scene);
        addItemStage.setTitle("Add to Cart");
        addItemStage.show();
    }

    private void handleAddToCart(int quantity) {
        if (quantity <= 0) {
            showAlert(Alert.AlertType.WARNING, "Warning", "Quantity must be greater than 0.");
            return;
        }
        Connect connection = Connect.getInstance();
        String userId = Login.getInstance().getUserID();

        try {
            String checkQuery = "SELECT * FROM carts WHERE UserID = '" + userId + "' AND ProductID = '" + productId + "'";
            ResultSet resultSet = connection.st.executeQuery(checkQuery);

            if (resultSet.next()) {
                String updateQuery = "UPDATE carts SET Quantity = " + quantity + " WHERE UserID = '" + userId + "' AND ProductID = '" + productId + "'";
                connection.st.executeUpdate(updateQuery);
                showAlert(Alert.AlertType.INFORMATION, "Success", "Product updated successfully.");
            } else {
                String insertQuery = "INSERT INTO carts (UserID, ProductID, Quantity) VALUES ('" + userId + "', '" + productId + "', " + quantity + ")";
                connection.st.executeUpdate(insertQuery);
                showAlert(Alert.AlertType.INFORMATION, "Success", "Product added successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error", "An error occurred while adding to the cart. " + e.getMessage());
        }
    }

    private int getCartQuantity(String productId) {
        Connect connection = Connect.getInstance();
        try {
            String query = "SELECT Quantity FROM carts WHERE ProductID = '" + productId + "'";
            ResultSet resultSet = connection.st.executeQuery(query);
            if (resultSet.next()) {
                return resultSet.getInt("Quantity");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText("message");
        alert.setContentText(message);
        alert.showAndWait();
    }
}
