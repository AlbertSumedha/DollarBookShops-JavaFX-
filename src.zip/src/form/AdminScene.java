package form;

import connect.Connect;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Spinner;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import models.Login;
import models.Product;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class AdminScene {

	private BorderPane borderPane;
	private Scene scene;
	private Stage primaryStage;
	private MenuBar menuBar;
	private Menu menu;
	private MenuItem home, cart, logout;
	private Label greetingLabel, nameLabel, genreLabel, stockLabel, priceLabel;
	private TableView<Product> tableView;
	private TextField nameTF, genreTF, priceTF;
	private Spinner<Integer> stockSpinner;
	private Button deleteBTN, addBTN, updateBTN;

	public AdminScene(Stage primaryStage) {
		this.primaryStage = primaryStage;
		init();
		setLayout();
	}

	private void init() {

		borderPane = new BorderPane();
		menuBar = new MenuBar();
		menu = new Menu("Action");
		home = new MenuItem("Home");
		cart = new MenuItem("Cart");
		logout = new MenuItem("Logout");
		menu.getItems().addAll(home, cart, logout);
		menuBar.getMenus().add(menu);

		home.setOnAction(e -> navigateToHome());
		logout.setOnAction(e -> logout());

		String currentUsername = Login.getInstance().getUsername();
		greetingLabel = new Label("Welcome Back, " + currentUsername);
		greetingLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

		tableView = new TableView<>();
		setupTableView();

		nameLabel = new Label("Name");
		nameTF = new TextField();
		nameTF.setPromptText("Name");

		genreLabel = new Label("Genre");
		genreTF = new TextField();
		genreTF.setPromptText("Genre");

		stockLabel = new Label("Stock");
		stockSpinner = new Spinner<>(0, 1000, 0);
		stockSpinner.setEditable(true);

		priceLabel = new Label("Price");
		priceTF = new TextField();
		priceTF.setPromptText("Price");

		deleteBTN = new Button("Delete");
		addBTN = new Button("Add");
		updateBTN = new Button("Update");

		VBox formBox = new VBox(5, new VBox(5, nameLabel, nameTF), new VBox(5, genreLabel, genreTF),
				new VBox(5, stockLabel, stockSpinner), new VBox(5, priceLabel, priceTF));
		formBox.setPadding(new Insets(10, 400, 0, 400));
		formBox.setSpacing(5);

		HBox buttonBox = new HBox(20, deleteBTN, addBTN, updateBTN);
		buttonBox.setPadding(new Insets(10, 10, 10, 10));
		buttonBox.setAlignment(Pos.CENTER);

		VBox bottomBox = new VBox(10, formBox, buttonBox);

		VBox topBox = new VBox(menuBar, greetingLabel);
		borderPane.setTop(topBox);
		borderPane.setCenter(tableView);
		borderPane.setBottom(bottomBox);

		tableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
			if (newSelection != null) {
				nameTF.setText(newSelection.getName());
				genreTF.setText(newSelection.getGenre());
				stockSpinner.getValueFactory().setValue(newSelection.getStock());
				priceTF.setText(String.valueOf(newSelection.getPrice()));
			}
		});

		deleteBTN.setOnAction(e -> {
			Product selectedProduct = tableView.getSelectionModel().getSelectedItem();

			if (selectedProduct == null) {
				showAlert(Alert.AlertType.WARNING, "Please select one product to delete.");
				return;
			}

			Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
			confirmation.setTitle("Delete Confirmation");
			confirmation.setHeaderText("Are you sure you want to delete this product?");
			confirmation.setContentText("Product: " + selectedProduct.getName());

			confirmation.showAndWait().ifPresent(response -> {
				if (response == ButtonType.OK) {
					try {
						Connect connection = Connect.getInstance();

						String deleteQuery = "DELETE FROM products WHERE ProductID = '" + selectedProduct.getProductId()
								+ "'";
						int rowsAffected = connection.st.executeUpdate(deleteQuery);

						if (rowsAffected > 0) {

							tableView.getItems().remove(selectedProduct);

							showAlert(Alert.AlertType.INFORMATION, "Product deleted successfully!");
						} else {
							showAlert(Alert.AlertType.ERROR, "Failed to delete product.");
						}
					} catch (Exception ex) {
						ex.printStackTrace();
						showAlert(Alert.AlertType.ERROR, "Error deleting product from the database.");
					}
				}
			});
		});

		addBTN.setOnAction(e -> {

			String newName = nameTF.getText().trim();
			String newGenre = genreTF.getText().trim();
			String stockText = stockSpinner.getValue().toString();
			String priceText = priceTF.getText().trim();

			if (newName.isEmpty() || newGenre.isEmpty() || stockText.isEmpty() || priceText.isEmpty()) {
				showAlert(Alert.AlertType.WARNING, "All fields must be filled.");
				return;
			}

			int newStock;
			int newPrice;

			try {
				newStock = Integer.parseInt(stockText);
				if (newStock <= 0) {
					showAlert(Alert.AlertType.WARNING, "Stock must be more than 0.");
					return;
				}
			} catch (NumberFormatException ex) {
				showAlert(Alert.AlertType.WARNING, "Stock must be a numeric value.");
				return;
			}

			try {
				newPrice = Integer.parseInt(priceText);
				if (newPrice <= 0) {
					showAlert(Alert.AlertType.WARNING, "Price must be more than 0.");
					return;
				}
			} catch (NumberFormatException ex) {
				showAlert(Alert.AlertType.WARNING, "Price must be a numeric value.");
				return;
			}

			try {
				Connect connection = Connect.getInstance();

				String getLastIdQuery = "SELECT ProductID FROM products ORDER BY ProductID DESC LIMIT 1";
				ResultSet rs = connection.st.executeQuery(getLastIdQuery);

				String newProductID = "PD001";

				if (rs.next()) {
					String lastID = rs.getString("ProductID");
					int nextID = Integer.parseInt(lastID.substring(2)) + 1;
					newProductID = String.format("PD%03d", nextID);
				}

				String insertQuery = "INSERT INTO products (ProductID, Name, Genre, Stock, Price) VALUES ('"
						+ newProductID + "', '" + newName + "', '" + newGenre + "', " + newStock + ", " + newPrice
						+ ")";

				int rowsAffected = connection.st.executeUpdate(insertQuery);

				if (rowsAffected > 0) {

					Product newProduct = new Product(newProductID, newName, newGenre, newStock, newPrice);
					tableView.getItems().add(newProduct);

					showAlert(Alert.AlertType.INFORMATION, "Product added successfully!");

					nameTF.clear();
					genreTF.clear();
					stockSpinner.getValueFactory().setValue(0);
					priceTF.clear();
				} else {
					showAlert(Alert.AlertType.ERROR, "Failed to add the product. Try again.");
				}
			} catch (Exception ex) {
				ex.printStackTrace();
				showAlert(Alert.AlertType.ERROR, "Error adding product to the database.");
			}
		});

		updateBTN.setOnAction(e -> {
			Product selectedProduct = tableView.getSelectionModel().getSelectedItem();

			if (selectedProduct == null) {
				showAlert(Alert.AlertType.WARNING, "Please select one product to update.");
				return;
			}

			String updatedName = nameTF.getText().trim();
			String updatedGenre = genreTF.getText().trim();
			String stockText = stockSpinner.getValue().toString();
			String priceText = priceTF.getText().trim();

			if (updatedName.isEmpty() || updatedGenre.isEmpty() || stockText.isEmpty() || priceText.isEmpty()) {
				showAlert(Alert.AlertType.WARNING, "All fields must be filled.");
				return;
			}

			int updatedStock;
			int updatedPrice;

			try {
				updatedStock = Integer.parseInt(stockText);
				if (updatedStock <= 0) {
					showAlert(Alert.AlertType.WARNING, "Stock must be more than 0.");
					return;
				}
			} catch (NumberFormatException ex) {
				showAlert(Alert.AlertType.WARNING, "Stock must be a numeric value.");
				return;
			}

			try {
				updatedPrice = Integer.parseInt(priceText);
				if (updatedPrice <= 0) {
					showAlert(Alert.AlertType.WARNING, "Price must be more than 0.");
					return;
				}
			} catch (NumberFormatException ex) {
				showAlert(Alert.AlertType.WARNING, "Price must be a numeric value.");
				return;
			}

			try {
				Connect connection = Connect.getInstance();

				String updateQuery = "UPDATE products SET Name = '" + updatedName + "', Genre = '" + updatedGenre
						+ "', Stock = " + updatedStock + ", Price = " + updatedPrice + " WHERE ProductID = '"
						+ selectedProduct.getProductId() + "'";

				int rowsAffected = connection.st.executeUpdate(updateQuery);

				if (rowsAffected > 0) {

					tableView.refresh();

					showAlert(Alert.AlertType.INFORMATION, "Product updated successfully!");
				} else {
					showAlert(Alert.AlertType.ERROR, "Failed to update product.");
				}
			} catch (Exception ex) {
				ex.printStackTrace();
				showAlert(Alert.AlertType.ERROR, "Error updating product in the database.");
			}

			tableView.refresh();
		});

	}

	private void showAlert(Alert.AlertType alertType, String message) {
		Alert alert = new Alert(alertType);
		alert.setTitle("Message");
		alert.setHeaderText(null);
		alert.setContentText(message);

		alert.showAndWait();
	}

	private void navigateToHome() {
		UserScene userScene = new UserScene(primaryStage);
		primaryStage.setScene(userScene.getScene());
	}

	private void logout() {
		SignIn login = new SignIn(primaryStage);
		primaryStage.setScene(login.getScene());
	}

	private void setupTableView() {
		TableColumn<Product, String> productIdCol = new TableColumn<>("Id");
		productIdCol.setCellValueFactory(new PropertyValueFactory<>("productId"));
		productIdCol.setPrefWidth(100);

		TableColumn<Product, String> nameCol = new TableColumn<>("Name");
		nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
		nameCol.setPrefWidth(200);

		TableColumn<Product, String> genreCol = new TableColumn<>("Genre");
		genreCol.setCellValueFactory(new PropertyValueFactory<>("genre"));
		genreCol.setPrefWidth(200);

		TableColumn<Product, Integer> stockCol = new TableColumn<>("Stock");
		stockCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
		stockCol.setPrefWidth(100);

		TableColumn<Product, Integer> priceCol = new TableColumn<>("Price");
		priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
		priceCol.setPrefWidth(100);

		tableView.getColumns().addAll(productIdCol, nameCol, genreCol, stockCol, priceCol);

		List<Product> products = getProducts();
		tableView.getItems().addAll(products);
	}

	private List<Product> getProducts() {
		List<Product> products = new ArrayList<>();
		Connect connection = Connect.getInstance();

		try {
			ResultSet resultSet = connection.st.executeQuery("SELECT * FROM products");
			while (resultSet.next()) {
				String productId = resultSet.getString("ProductID");
				String name = resultSet.getString("Name");
				String genre = resultSet.getString("Genre");
				int stock = resultSet.getInt("Stock");
				int price = resultSet.getInt("Price");

				products.add(new Product(productId, name, genre, stock, price));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return products;
	}

	private void setLayout() {
		scene = new Scene(borderPane, 1000, 600);
	}

	public Scene getScene() {
		return scene;
	}
}
