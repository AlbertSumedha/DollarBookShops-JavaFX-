package form;

import connect.Connect;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import models.Cart;
import models.Login;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CustomerCart {

    private BorderPane borderPane;
    private Scene scene;
    private Stage primaryStage;
    private MenuBar menuBar;
    private Menu menu;
    private MenuItem home, cart, logout;
    private Label greetingLabel;
    private TableView<Cart> tableView;
    private Button updateButton, removeButton, checkoutButton;
    private Spinner<Integer> quantitySpinner;
    private HBox buttonBox;
    private VBox topBox;

    public CustomerCart(Stage primaryStage) {
        this.primaryStage = primaryStage;
        init();
        setLayout();
    }

    private void init() {
        borderPane = new BorderPane();
        menuBar = new MenuBar();
        menu = new Menu("Action");
        home = new MenuItem("Home");
        cart = new MenuItem("Cart");
        logout = new MenuItem("Logout");
        menu.getItems().addAll(home, cart, logout);
        menuBar.getMenus().add(menu);
        
        home.setOnAction(e -> navigateToHome());
        cart.setOnAction(e -> navigateToCart());
        logout.setOnAction(e -> logout());

        String currentUsername = Login.getInstance().getUsername();
        greetingLabel = new Label(currentUsername + "'s Cart");
        greetingLabel.setStyle("-fx-font-size: 40px; -fx-font-weight: bold;");

        tableView = new TableView<>();
        setupTableView();

        quantitySpinner = new Spinner<>();
        quantitySpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 100, 1));
        quantitySpinner.setEditable(true);

        updateButton = new Button("Update Quantity");
        removeButton = new Button("Remove Item");
        checkoutButton = new Button("Checkout");

        updateButton.setOnAction(e -> updateQuantity());
        removeButton.setOnAction(e -> removeItem());
        checkoutButton.setOnAction(e -> checkout());

        buttonBox = new HBox(10, quantitySpinner, removeButton, checkoutButton, updateButton);
        buttonBox.setStyle("-fx-padding: 10; -fx-alignment: center;");

        topBox = new VBox(menuBar, greetingLabel);
        borderPane.setTop(topBox);
        borderPane.setCenter(tableView);
        borderPane.setBottom(buttonBox);

        tableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                quantitySpinner.getValueFactory().setValue(newSelection.getQuantity());
            }
        });
    }

    private void setupTableView() {
        TableColumn<Cart, String> productIdCol = new TableColumn<>("Id");
        productIdCol.setCellValueFactory(new PropertyValueFactory<>("productId"));
        productIdCol.setPrefWidth(150);

        TableColumn<Cart, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("productName"));
        nameCol.setPrefWidth(200);

        TableColumn<Cart, String> genreCol = new TableColumn<>("Genre");
        genreCol.setCellValueFactory(new PropertyValueFactory<>("genre"));
        genreCol.setPrefWidth(150);

        TableColumn<Cart, Double> priceCol = new TableColumn<>("Price");
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        priceCol.setPrefWidth(100);

        TableColumn<Cart, Integer> quantityCol = new TableColumn<>("Quantity");
        quantityCol.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        quantityCol.setPrefWidth(100);

        TableColumn<Cart, Double> totalCol = new TableColumn<>("Total");
        totalCol.setCellValueFactory(new PropertyValueFactory<>("totalPrice"));
        totalCol.setPrefWidth(120);

        tableView.getColumns().addAll(productIdCol, nameCol, genreCol, priceCol, quantityCol, totalCol);

        List<Cart> cartItems = getCartItems();
        tableView.getItems().addAll(cartItems);
    }
    
    private void navigateToCart() {
        CustomerCart customerCart = new CustomerCart(primaryStage);
        primaryStage.setScene(customerCart.getScene()); 
    }

    private void navigateToHome() {
        UserScene userScene = new UserScene(primaryStage);
        primaryStage.setScene(userScene.getScene());
    }

    private void logout() {
        SignIn login = new SignIn(primaryStage);
        primaryStage.setScene(login.getScene());
    }

    private List<Cart> getCartItems() {
        List<Cart> cartItems = new ArrayList<>();
        Connect connection = Connect.getInstance();

        try {
            ResultSet rs = connection.st.executeQuery(
                    "SELECT c.ProductID, p.Name, p.Genre, p.Price, c.Quantity " +
                            "FROM carts c JOIN products p ON c.ProductID = p.ProductID " +
                            "WHERE c.UserID = '" + Login.getInstance().getUserID() + "'"
            );
            while (rs.next()) {
                cartItems.add(new Cart(
                        rs.getString("ProductID"),
                        rs.getString("Name"),
                        rs.getString("Genre"),
                        rs.getDouble("Price"),
                        rs.getInt("Quantity")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return cartItems;
    }

    private void updateQuantity() {
    	Cart selectedItem = tableView.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            return;
        }

        int newQuantity = quantitySpinner.getValue(); 
        if (newQuantity <= 0) {
            return;
        }

        try {
            Connect connection = Connect.getInstance();
            
            String updateQuery = "UPDATE carts SET Quantity = " + newQuantity + 
                                 " WHERE ProductID = '" + selectedItem.getProductId() + 
                                 "' AND UserID = '" + Login.getInstance().getUserID() + "'";
            
            connection.st.executeUpdate(updateQuery);

            selectedItem.setQuantity(newQuantity);
            tableView.refresh();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void removeItem() {
    	Cart selectedItem = tableView.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            return;
        }

        try {
            Connect connection = Connect.getInstance();
            String deleteQuery = "DELETE FROM carts WHERE ProductID = '" + selectedItem.getProductId() + 
                                 "' AND UserID = '" + Login.getInstance().getUserID() + "'";
            connection.st.executeUpdate(deleteQuery);
            tableView.getItems().remove(selectedItem);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void checkout() {
        Cart selectedItem = tableView.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            System.out.println("Please select a product to checkout.");
            return;
        }

        String transactionID = generateTransactionID();
        String productId = selectedItem.getProductId();
        int quantity = selectedItem.getQuantity();

        try {
            Connect connection = Connect.getInstance();
        
            connection.st.executeUpdate("START TRANSACTION");

            int rowsInserted = connection.st.executeUpdate(
                    "INSERT INTO transaction_headers (TransactionID, UserID, TransactionDate) VALUES ('" +
                    transactionID + "', '" + Login.getInstance().getUserID() + "', NOW())"
            );
            ResultSet rs = connection.st.executeQuery(
                    "SELECT Price FROM products WHERE ProductID = '" + productId + "'"
            );
            double price = 0.0;
            if (rs.next()) {
                price = rs.getDouble("Price");
            }
            rowsInserted = connection.st.executeUpdate(
                    "INSERT INTO transaction_details (TransactionID, ProductID, Quantity) " +
                    "VALUES ('" + transactionID + "', '" + productId + "', " + quantity + ")"
            );
            connection.st.executeUpdate(
                    "UPDATE products SET Stock = Stock - " + quantity + " WHERE ProductID = '" + productId + "'"
            );
            connection.st.executeUpdate(
                    "DELETE FROM carts WHERE ProductID = '" + productId + "' AND UserID = '" + Login.getInstance().getUserID() + "'"
            );
            connection.st.executeUpdate("COMMIT");
            tableView.getItems().remove(selectedItem);

        } catch (SQLException e) {
            try {
                Connect connection = Connect.getInstance();
                connection.st.executeUpdate("ROLLBACK");
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
            }
            e.printStackTrace();
        }
    }


    private String generateTransactionID() {
        String newTransactionID = "TR001";

        try {
            Connect connection = Connect.getInstance();
            ResultSet rs = connection.st.executeQuery("SELECT MAX(TransactionID) AS lastTransactionID FROM transaction_headers");

            if (rs.next()) {
                String lastTransactionID = rs.getString("lastTransactionID");
                if (lastTransactionID != null) {
                    int lastId = Integer.parseInt(lastTransactionID.substring(2));
                    newTransactionID = "TR" + String.format("%03d", lastId + 1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return newTransactionID;
    }

    private void setLayout() {
        scene = new Scene(borderPane, 1000, 600);
    }

    public Scene getScene() {
        return scene;
    }
}
