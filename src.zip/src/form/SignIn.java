package form;

import connect.Connect;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import models.Login;

import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class SignIn {

    private GridPane gridPane;
    private Label titleLbl, emailLbl, passwordLbl;
    private TextField emailTF;
    private PasswordField passwordPF;
    private Button button;
    private Hyperlink signupLink;
    private Stage primaryStage;

    public SignIn(Stage primaryStage) {
        this.primaryStage = primaryStage;
        init();
        setLayout();
        addEventHandlers();
    }

    private void init() {
        gridPane = new GridPane();

        titleLbl = new Label("Login");
        titleLbl.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        emailLbl = new Label("Email");
        passwordLbl = new Label("Password");

        emailTF = new TextField();
        emailTF.setPromptText("Email Address");

        passwordPF = new PasswordField();
        passwordPF.setPromptText("Password");

        signupLink = new Hyperlink("Don't have an account? Register here!");
        signupLink.setStyle("-fx-text-fill: #0000ee;");

        button = new Button("Sign In");
        button.setStyle("-fx-background-color: #00b7c2; -fx-text-fill: white;");
    }

    private void setLayout() {
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setPadding(new Insets(25, 25, 25, 25));

        gridPane.add(titleLbl, 0, 0, 2, 1);
        gridPane.add(emailLbl, 0, 1);
        gridPane.add(emailTF, 0, 2);
        gridPane.add(passwordLbl, 0, 3);
        gridPane.add(passwordPF, 0, 4);
        gridPane.add(button, 0, 5);
        gridPane.add(signupLink, 0, 6);
    }

    private void addEventHandlers() {
        button.setOnAction(e -> {
            if (validateInputs()) {
                try {
                    if (checkCredentials()) {
                        redirectToHome();
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    showAlert(Alert.AlertType.ERROR, "Database error: " + ex.getMessage());
                }
            }
        });

        signupLink.setOnAction(e -> redirectToSignUp());
    }

    private boolean validateInputs() {
        String email = emailTF.getText();
        String password = passwordPF.getText();

        if (email == null || email.isEmpty() || password == null || password.isEmpty()) {
            showGenericErrorAlert();
            return false;
        }
        return true;
    }

    private void showGenericErrorAlert() {
        showAlert(Alert.AlertType.WARNING, "Invalid credentials");
    }

    private void showAlert(Alert.AlertType alertType, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle("Warning");
        alert.setHeaderText("Warning");
        alert.setContentText(message);

        ButtonType okButton = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
        alert.getButtonTypes().setAll(okButton);

        alert.showAndWait();
    }

    private boolean checkCredentials() throws SQLException {
        Connect conn = Connect.getInstance();
        String email = emailTF.getText();
        String password = passwordPF.getText();

        String query = "SELECT * FROM users WHERE email = ? AND password = ?";
        PreparedStatement pstmt = conn.con.prepareStatement(query);
        pstmt.setString(1, email);
        pstmt.setString(2, password);
        ResultSet rs = pstmt.executeQuery();

        if (rs.next()) {
            String role = rs.getString("Role"); 
            Login.getInstance().setUserID(rs.getString("UserID"));
            Login.getInstance().setUsername(rs.getString("Username"));
            Login.getInstance().setRole(role);
            return true;
        } 
        else {
        	showGenericErrorAlert();
            return false;
        }
    }
    private void redirectToSignUp() {
        SignUp signUp = new SignUp(primaryStage);
        primaryStage.setScene(signUp.getScene());
    }

    private void redirectToHome() {
        String role = Login.getInstance().getRole();
        if ("admin".equalsIgnoreCase(role)) {
            AdminScene adminHome = new AdminScene(primaryStage);
            primaryStage.setScene(adminHome.getScene());
        } else if ("user".equalsIgnoreCase(role)) {
            UserScene customerHome = new UserScene(primaryStage);
            primaryStage.setScene(customerHome.getScene());
        } else {
            showAlert(Alert.AlertType.ERROR, "Unknown role: " + role);
        }
    }

    public Scene getScene() {
        return new Scene(gridPane, 600, 600);
    }
}
