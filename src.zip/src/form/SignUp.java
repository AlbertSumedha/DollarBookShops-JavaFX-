package form;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.time.Period;

import connect.Connect;

public class SignUp {

    private GridPane gridPane;
    private Label titleLbl, nameLbl, emailLbl, passwordLbl, cpasswordLbl, dobLbl;
    private TextField nameTF, emailTF;
    private PasswordField passwordPF, cpasswordPF;
    private Button button;
    private DatePicker datePicker;
    private Hyperlink signinLink;
    private Stage primaryStage;

    public SignUp(Stage primaryStage) {
        this.primaryStage = primaryStage;
        init();
        setLayout();
        addEventHandlers();
    }

    private void init() {
        gridPane = new GridPane();

        titleLbl = new Label("REGISTER");
        titleLbl.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        nameLbl = new Label("Username");
        emailLbl = new Label("Email");
        passwordLbl = new Label("Password");
        cpasswordLbl = new Label("Confirm Password");
        dobLbl = new Label("Date of Birth");

        nameTF = new TextField();
        nameTF.setPromptText("Username");
        emailTF = new TextField();
        emailTF.setPromptText("Email Address");

        passwordPF = new PasswordField();
        passwordPF.setPromptText("Password");
        cpasswordPF = new PasswordField();
        cpasswordPF.setPromptText("Confirm Password");

        datePicker = new DatePicker();

        signinLink = new Hyperlink("Already have an account? Login here!");
        signinLink.setStyle("-fx-text-fill: #0000ee;");

        button = new Button("Sign Up");
        button.setStyle("-fx-background-color: #00b7c2; -fx-text-fill: white;");
    }

    private void setLayout() {
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setPadding(new Insets(25, 25, 25, 25));

        gridPane.add(titleLbl, 0, 0, 2, 1);
        gridPane.add(emailLbl, 0, 1);
        gridPane.add(emailTF, 0, 2);
        gridPane.add(nameLbl, 0, 3);
        gridPane.add(nameTF, 0, 4);
        gridPane.add(passwordLbl, 0, 5);
        gridPane.add(passwordPF, 0, 6);
        gridPane.add(cpasswordLbl, 0, 7);
        gridPane.add(cpasswordPF, 0, 8);
        gridPane.add(dobLbl, 0, 9);
        gridPane.add(datePicker, 0, 10);
        gridPane.add(button, 0, 11);
        gridPane.add(signinLink, 0, 12);
    }

    private boolean validateInputs() {
        try {
            String username = nameTF.getText();
            String email = emailTF.getText();
            String password = passwordPF.getText();
            String confirmPassword = cpasswordPF.getText();
            LocalDate dob = datePicker.getValue();

            if (username == null || username.isEmpty() ||
                email == null || email.isEmpty() ||
                password == null || password.isEmpty() ||
                confirmPassword == null || confirmPassword.isEmpty() ||
                dob == null || username.length() <= 5 ||
                !email.contains("@") ||
                password.length() <= 8 || !checker(password) ||
                !password.equals(confirmPassword) ||
                Period.between(dob, LocalDate.now()).getYears() < 18) {

                showGenericErrorAlert("All fields must be filled!");
                return false;
            }

            if (!isUnique("Username", username)) {
            	showGenericErrorAlert("All fields must be filled!");
                return false;
            }

            if (!isUnique("Email", email)) {
            	showGenericErrorAlert("All fields must be filled!");
                return false;
            }

            return true;
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Validation error: " + e.getMessage());
            return false;
        }
    }

    private boolean isUnique(String column, String value) throws SQLException {
        Connect conn = Connect.getInstance();
        String query = "SELECT COUNT(*) FROM users WHERE " + column + " = ?";
        try (PreparedStatement pstmt = conn.con.prepareStatement(query)) {
            pstmt.setString(1, value);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                return false;
            }
        }
        return true;
    }

    private void addEventHandlers() {
        button.setOnAction(e -> {
            if (validateInputs()) {
                try {
                    registerUser();
                } catch (SQLException ex) {
                    showAlert(Alert.AlertType.ERROR, "Database error: " + ex.getMessage());
                }
            }
        });

        signinLink.setOnAction(e -> redirectToSignIn());
    }

    private void registerUser() throws SQLException {
        Connect conn = Connect.getInstance();
        String userID = generateUserId();

        String query = "INSERT INTO users (UserID, Username, Email, Password, DOB, Role) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.con.prepareStatement(query)) {
            pstmt.setString(1, userID);
            pstmt.setString(2, nameTF.getText());
            pstmt.setString(3, emailTF.getText());
            pstmt.setString(4, passwordPF.getText());
            pstmt.setDate(5, Date.valueOf(datePicker.getValue()));
            pstmt.setString(6, "user");
            pstmt.executeUpdate();
        }
        redirectToSignIn();
    }

    private String generateUserId() throws SQLException {
        Connect conn = Connect.getInstance();
        String query = "SELECT COUNT(*) FROM users";
        try (Statement stmt = conn.con.createStatement()) {
            ResultSet rs = stmt.executeQuery(query);
            if (rs.next()) {
                int count = rs.getInt(1) + 1;
                return String.format("US%03d", count);
            }
        }
        return "US001"; // Default if no users found
    }

    private void redirectToSignIn() {
        SignIn signIn = new SignIn(primaryStage);
        primaryStage.setScene(signIn.getScene());
    }

    public Scene getScene() {
        return new Scene(gridPane, 600, 600);
    }

    private void showGenericErrorAlert(String message) {
        showAlert(Alert.AlertType.WARNING, message);
    }

    private void showAlert(Alert.AlertType alertType, String message) {
        Alert alert = new Alert(alertType);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    private boolean checker(String password) {
        boolean hasLetter = false;
        boolean hasDigit = false;
        for (int i = 0; i < password.length(); i++) {
            char ch = password.charAt(i);
            if (Character.isAlphabetic(ch)) {
                hasLetter = true;
            } else if (Character.isDigit(ch)) {
                hasDigit = true;
            } else {
                return false;
            }
        }
        return hasLetter && hasDigit;
    }

}