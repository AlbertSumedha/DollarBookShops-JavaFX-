package form;

import connect.Connect;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import jfxtras.labs.scene.control.window.Window;
import models.Login;
import models.Product;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class UserScene {

    private BorderPane borderPane;
    private Scene scene;
    private Stage primaryStage;
    private MenuBar menuBar;
    private Menu menu;
    private MenuItem home, cart, logout;
    private Label greetingLabel;
    private TableView<Product> tableView;

    public UserScene(Stage primaryStage) {
        this.primaryStage = primaryStage;
        init();
        setLayout();
    }

    private void init() {
        borderPane = new BorderPane();

        menuBar = new MenuBar();
        menu = new Menu("Action");
        home = new MenuItem("Home");
        cart = new MenuItem("Cart");
        logout = new MenuItem("Logout");
        menu.getItems().addAll(home, cart, logout);
        menuBar.getMenus().add(menu);

        home.setOnAction(e -> navigateToHome());
        cart.setOnAction(e -> navigateToCart());
        logout.setOnAction(e -> logout());

        String currentUsername = Login.getInstance().getUsername(); 
        greetingLabel = new Label("Hello, " + currentUsername);
        greetingLabel.setStyle("-fx-font-size: 40px; -fx-font-weight: bold;");

        tableView = new TableView<>();
        setupTableView();

        Button addToCartButton = new Button("Add to Cart");
        addToCartButton.setOnAction(e -> openAddItem());

        HBox buttonBox = new HBox(addToCartButton);
        buttonBox.setStyle("-fx-padding: 10; -fx-alignment: center;");

        VBox topBox = new VBox(menuBar, greetingLabel);
        borderPane.setTop(topBox);
        borderPane.setCenter(tableView);
        borderPane.setBottom(buttonBox); 
    }
    
    private void navigateToCart() {
        CustomerCart customerCart = new CustomerCart(primaryStage);
        primaryStage.setScene(customerCart.getScene());
    }

    private void navigateToHome() {
        UserScene userScene = new UserScene(primaryStage);
        primaryStage.setScene(userScene.getScene());
    }
    
    private void logout() {
        SignIn login = new SignIn(primaryStage);
        primaryStage.setScene(login.getScene());
    }


    private void setupTableView() {
        // Define columns for TableView
        TableColumn<Product, String> productIdCol = new TableColumn<>("Id");
        productIdCol.setCellValueFactory(new PropertyValueFactory<>("productId"));
        productIdCol.setPrefWidth(200);

        TableColumn<Product, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        nameCol.setPrefWidth(200); 

        TableColumn<Product, String> genreCol = new TableColumn<>("Genre");
        genreCol.setCellValueFactory(new PropertyValueFactory<>("genre"));
        genreCol.setPrefWidth(200); 

        TableColumn<Product, Integer> stockCol = new TableColumn<>("Stock");
        stockCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        stockCol.setPrefWidth(200); 

        TableColumn<Product, Integer> priceCol = new TableColumn<>("Price");
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        priceCol.setPrefWidth(200); 

        tableView.getColumns().addAll(productIdCol, nameCol, genreCol, stockCol, priceCol);

        List<Product> products = getProducts();
        tableView.getItems().addAll(products);
    }

    private List<Product> getProducts() {
        List<Product> products = new ArrayList<>();
        Connect connection = Connect.getInstance();

        try {
            ResultSet resultSet = connection.st.executeQuery("SELECT * FROM products");
            while (resultSet.next()) {
                String productId = resultSet.getString("ProductID");
                String name = resultSet.getString("Name");
                String genre = resultSet.getString("Genre");
                int stock = resultSet.getInt("Stock");
                int price = resultSet.getInt("Price");

                products.add(new Product(productId, name, genre, stock, price));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return products;
    }

    private void openAddItem() {
        Product selectedProduct = tableView.getSelectionModel().getSelectedItem();
        if (selectedProduct != null) {
            AddItem addItem = new AddItem(
                primaryStage,
                selectedProduct.getProductId(),
                selectedProduct.getName(),
                selectedProduct.getGenre(),
                selectedProduct.getPrice(),
                selectedProduct.getStock()
            );
            addItem.show();
        } else {
            showAlert(Alert.AlertType.WARNING, "you need to select one product");
        }
    }

    private void showAlert(Alert.AlertType alertType, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle("Warning");
        alert.setHeaderText("Warning");
        alert.setContentText(message);

        ButtonType okButton = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
        alert.getButtonTypes().setAll(okButton);

        alert.showAndWait();
    }

    private void setLayout() {
        scene = new Scene(borderPane, 1000, 600);
    }

    public Scene getScene() {
        return scene;
    }

    public MenuBar getMenuBar() {
        return menuBar;
    }
}