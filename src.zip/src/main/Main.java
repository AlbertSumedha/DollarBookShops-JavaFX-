package main;

import form.SignIn;
import form.SignUp;
import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application{

	public static void main(String[] args) {
		launch(args);

	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		SignIn signUp = new SignIn(primaryStage);
        primaryStage.setScene(signUp.getScene());
        primaryStage.setTitle("Dollar Book Shop");
        primaryStage.show();
	}

}
