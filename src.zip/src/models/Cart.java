package models;

public class Cart {

	private String productId;
	private String productName;
	private String genre;
	private double price;
	private int quantity;
	
	public Cart(String productId, String productName, String genre, double price, int quantity) {
		this.productId = productId;
		this.productName = productName;
		this.genre = genre;
		this.price = price;
		this.quantity = quantity;
	}

	public String getProductId() { 
		return productId; 
	}
	
	public String getProductName() { 
		return productName; 
	}
	
	public String getGenre() { 
		return genre; 
	}
	
	public double getPrice() { 
		return price;
	}
	
	public int getQuantity() {
		return quantity; 
	}
	
	public void setQuantity(int quantity) {
		this.quantity = quantity; 
	}
	
	public double getTotalPrice() {
		return price * quantity; 
	}
}