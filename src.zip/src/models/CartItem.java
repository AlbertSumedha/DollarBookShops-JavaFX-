package models;

import javafx.beans.property.*;

public class CartItem {
    private final StringProperty userId;
    private final StringProperty productId;
    private final StringProperty name;
    private final StringProperty genre;
    private final IntegerProperty quantity;
    private final IntegerProperty price;

    public CartItem(String userId, String productId, String name, String genre, int quantity, int price) {
        this.userId = new SimpleStringProperty(userId);
        this.productId = new SimpleStringProperty(productId);
        this.name = new SimpleStringProperty(name);
        this.genre = new SimpleStringProperty(genre);
        this.quantity = new SimpleIntegerProperty(quantity);
        this.price = new SimpleIntegerProperty(price);
    }

    public String getUserId() {
        return userId.get();
    }

    public StringProperty userIdProperty() {
        return userId;
    }

    public String getProductId() {
        return productId.get();
    }

    public StringProperty productIdProperty() {
        return productId;
    }

    public String getName() {
        return name.get();
    }

    public StringProperty nameProperty() {
        return name;
    }

    public String getGenre() {
        return genre.get();
    }

    public StringProperty genreProperty() {
        return genre;
    }

    public int getQuantity() {
        return quantity.get();
    }

    public IntegerProperty quantityProperty() {
        return quantity;
    }

    public int getPrice() {
        return price.get();
    }

    public IntegerProperty priceProperty() {
        return price;
    }

    public int getTotal() {
        return getPrice() * getQuantity();
    }
}
