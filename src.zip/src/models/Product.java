package models;

public class Product {
    private String productId;
    private String name;
    private String genre;
    private int stock;
    private int price;

    public Product(String productId, String name, String genre, int stock, int price) {
        this.productId = productId;
        this.name = name;
        this.genre = genre;
        this.stock = stock;
        this.price = price;
    }

    public String getProductId() { 
    	return productId; 
    }
    
    public String getName() { 
    	return name; 
    }
    
    public String getGenre() { 
    	return genre; 
    }
    
    public int getStock() { 
    	return stock; 
    }
    
    public int getPrice() { 
    	return price; 
    }
}