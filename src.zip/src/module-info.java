module DollarBookShops {
	exports models;
	exports form;
	exports main;
	exports connect;

	requires java.sql;
	requires javafx.base;
	requires javafx.controls;
	requires javafx.graphics;
	requires jfxtras.labs;
}